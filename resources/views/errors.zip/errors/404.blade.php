<style>

    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes float{ 0% { -webkit-transform: translate(0, 0px) scale(0.95); } 65% { -webkit-transform: translate(0, 30px) scale(1.0); } 100% { -webkit-transform: translate(0, -0px) scale(0.95); } }
    @-moz-keyframes float{ 0% { -moz-transform: translate(0, 0px) scale(0.95); } 65% { -moz-transform: translate(0, 30px) scale(1.0); } 100% { -moz-transform: translate(0, -0px) scale(0.95); } }
    @-o-keyframes float{ 0% { -o-transform: translate(0, 0px) scale(0.95); } 65% { -o-transform: translate(0, 30px) scale(1.0); } 100% { -o-transform: translate(0, -0px) scale(0.95); } }
    @keyframes float{ 0% {-webkit-transform: translate(0, 0px) scale(0.95);-moz-transform: translate(0, 0px) scale(0.95);-ms-transform: translate(0, 0px) scale(0.95);transform: translate(0, 0px) scale(0.95); } 65% {-webkit-transform: translate(0, 30px) scale(1.0);-moz-transform: translate(0, 30px) scale(1.0);-ms-transform: translate(0, 30px) scale(1.0);transform: translate(0, 30px) scale(1.0); } 100% {-webkit-transform: translate(0, -0px) scale(0.95);-moz-transform: translate(0, -0px) scale(0.95);-ms-transform: translate(0, -0px) scale(0.95);transform: translate(0, -0px) scale(0.95); } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes fade{ 0% { opacity: 0.10; left: 160px; -webkit-transform:skewX(20deg); } 65% { opacity: 0.4; left: 114px; -webkit-transform:skewX(0deg); } 100% { opacity: 0.10; left: 160px; -webkit-transform:skewX(20deg); } }
    @-moz-keyframes fade{ 0% { opacity: 0.10; left: 160px; -moz-transform:skewX(20deg); } 65% { opacity: 0.4; left: 114px; -moz-transform:skewX(0deg); } 100% { opacity: 0.10; left: 160px; -moz-transform:skewX(20deg); } }
    @-o-keyframes fade{ 0% { opacity: 0.10; left: 160px; -o-transform:skewX(20deg); } 65% { opacity: 0.4; left: 114px; -o-transform:skewX(0deg); } 100% { opacity: 0.10; left: 160px; -o-transform:skewX(20deg); } }
    @keyframes fade{ 0% { opacity: 0.10; left: 160px;-webkit-transform:skewX(20deg);-moz-transform:skewX(20deg);-ms-transform:skewX(20deg);transform:skewX(20deg); } 65% { opacity: 0.4; left: 114px;-webkit-transform:skewX(0deg);-moz-transform:skewX(0deg);-ms-transform:skewX(0deg);transform:skewX(0deg); } 100% { opacity: 0.10; left: 160px;-webkit-transform:skewX(20deg);-moz-transform:skewX(20deg);-ms-transform:skewX(20deg);transform:skewX(20deg); } }
    [not-existing] {
        zoom: 1;
    }
    .me404 {
        height: 451px;
        width: 840px;
        position: absolute;
        top: 50%;
        left: 50%;
        margin-left: -420px;
        margin-top: -225px;
    }
    .clouds {
        background: url("http://yagz.net/testrealm/404/clouds.png");
        width: 643px;
        height: 304px;
        position: absolute;
        left: 134px;
        top: 61px;
        -webkit-animation: clouds 9s infinite ease-in-out;
        -moz-animation: clouds 9s infinite ease-in-out;
        -o-animation: clouds 9s infinite ease-in-out;
        animation: clouds 9s infinite ease-in-out;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes clouds{ 0% { opacity: 0.10; left: 160px; -webkit-transform:skewX(20deg); } 65% { opacity: 0.4; left: 114px; -webkit-transform:skewX(0deg); } 100% { opacity: 0.10; left: 160px; -webkit-transform:skewX(20deg); } }
    @-moz-keyframes clouds{ 0% { opacity: 0.10; left: 160px; -moz-transform:skewX(20deg); } 65% { opacity: 0.4; left: 114px; -moz-transform:skewX(0deg); } 100% { opacity: 0.10; left: 160px; -moz-transform:skewX(20deg); } }
    @-o-keyframes clouds{ 0% { opacity: 0.10; left: 160px; -o-transform:skewX(20deg); } 65% { opacity: 0.4; left: 114px; -o-transform:skewX(0deg); } 100% { opacity: 0.10; left: 160px; -o-transform:skewX(20deg); } }
    @keyframes clouds{ 0% { opacity: 0.10; left: 160px;-webkit-transform:skewX(20deg);-moz-transform:skewX(20deg);-ms-transform:skewX(20deg);transform:skewX(20deg); } 65% { opacity: 0.4; left: 114px;-webkit-transform:skewX(0deg);-moz-transform:skewX(0deg);-ms-transform:skewX(0deg);transform:skewX(0deg); } 100% { opacity: 0.10; left: 160px;-webkit-transform:skewX(20deg);-moz-transform:skewX(20deg);-ms-transform:skewX(20deg);transform:skewX(20deg); } }
    [not-existing] {
        zoom: 1;
    }
    .the404 {
        background: url("http://yagz.net/testrealm/404/404.png");
        width: 352px;
        height: 142px;
        position: absolute;
        left: 242px;
        top: 129px;
    }
    .monkey {
        background: url("http://yagz.net/testrealm/404/monkeya.png");
        width: 169px;
        height: 140px;
        position: absolute;
        left: 31px;
        top: 218px;
    }
    .monkey-eye-l {
        background: url("http://yagz.net/testrealm/404/monkey-eye-l.png");
        width: 6px;
        height: 6px;
        position: absolute;
        left: 127px;
        top: 27px;
        -webkit-animation: blink-l 12s infinite ease-in-out;
        -moz-animation: blink-l 12s infinite ease-in-out;
        -o-animation: blink-l 12s infinite ease-in-out;
        animation: blink-l 12s infinite ease-in-out;
    }
    .monkey-eye-r {
        background: url("http://yagz.net/testrealm/404/monkey-eye-r.png");
        width: 5px;
        height: 5px;
        position: absolute;
        left: 141px;
        top: 27px;
        -webkit-animation: blink-r 12s infinite ease-in-out;
        -moz-animation: blink-r 12s infinite ease-in-out;
        -o-animation: blink-r 12s infinite ease-in-out;
        animation: blink-r 12s infinite ease-in-out;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes blink-l{ 0% { -webkit-transform: rotateX(0deg); } 2% { -webkit-transform: rotateX(80deg); } 4%,20% { -webkit-transform: rotateX(0deg); } 22% { -webkit-transform: rotateX(80deg); } 24%,30% { -webkit-transform: rotateX(0deg); } 32% { -webkit-transform: rotateX(80deg); } 34%,70% { -webkit-transform: rotateX(0deg); } 72% { -webkit-transform: rotateX(80deg); } 74%,100% { -webkit-transform: rotateX(0deg); }}
    @-moz-keyframes blink-l{ 0% { -moz-transform: rotateX(0deg); } 2% { -moz-transform: rotateX(80deg); } 4%,20% { -moz-transform: rotateX(0deg); } 22% { -moz-transform: rotateX(80deg); } 24%,30% { -moz-transform: rotateX(0deg); } 32% { -moz-transform: rotateX(80deg); } 34%,70% { -moz-transform: rotateX(0deg); } 72% { -moz-transform: rotateX(80deg); } 74%,100% { -moz-transform: rotateX(0deg); }}
    @-o-keyframes blink-l{ 0% { -o-transform: rotateX(0deg); } 2% { -o-transform: rotateX(80deg); } 4%,20% { -o-transform: rotateX(0deg); } 22% { -o-transform: rotateX(80deg); } 24%,30% { -o-transform: rotateX(0deg); } 32% { -o-transform: rotateX(80deg); } 34%,70% { -o-transform: rotateX(0deg); } 72% { -o-transform: rotateX(80deg); } 74%,100% { -o-transform: rotateX(0deg); }}
    @keyframes blink-l{ 0% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); } 2% {-webkit-transform: rotateX(80deg);-moz-transform: rotateX(80deg);-ms-transform: rotateX(80deg);transform: rotateX(80deg); } 4%,20% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); } 22% {-webkit-transform: rotateX(80deg);-moz-transform: rotateX(80deg);-ms-transform: rotateX(80deg);transform: rotateX(80deg); } 24%,30% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); } 32% {-webkit-transform: rotateX(80deg);-moz-transform: rotateX(80deg);-ms-transform: rotateX(80deg);transform: rotateX(80deg); } 34%,70% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); } 72% {-webkit-transform: rotateX(80deg);-moz-transform: rotateX(80deg);-ms-transform: rotateX(80deg);transform: rotateX(80deg); } 74%,100% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); }}
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes blink-r{ 0% { -webkit-transform: rotateX(0deg); } 2% { -webkit-transform: rotateX(80deg); } 4%,30% { -webkit-transform: rotateX(0deg); } 32% { -webkit-transform: rotateX(80deg); } 34%,50% { -webkit-transform: rotateX(0deg); } 52% { -webkit-transform: rotateX(80deg); } 54%,100% { -webkit-transform: rotateX(0deg); } }
    @-moz-keyframes blink-r{ 0% { -moz-transform: rotateX(0deg); } 2% { -moz-transform: rotateX(80deg); } 4%,30% { -moz-transform: rotateX(0deg); } 32% { -moz-transform: rotateX(80deg); } 34%,50% { -moz-transform: rotateX(0deg); } 52% { -moz-transform: rotateX(80deg); } 54%,100% { -moz-transform: rotateX(0deg); } }
    @-o-keyframes blink-r{ 0% { -o-transform: rotateX(0deg); } 2% { -o-transform: rotateX(80deg); } 4%,30% { -o-transform: rotateX(0deg); } 32% { -o-transform: rotateX(80deg); } 34%,50% { -o-transform: rotateX(0deg); } 52% { -o-transform: rotateX(80deg); } 54%,100% { -o-transform: rotateX(0deg); } }
    @keyframes blink-r{ 0% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); } 2% {-webkit-transform: rotateX(80deg);-moz-transform: rotateX(80deg);-ms-transform: rotateX(80deg);transform: rotateX(80deg); } 4%,30% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); } 32% {-webkit-transform: rotateX(80deg);-moz-transform: rotateX(80deg);-ms-transform: rotateX(80deg);transform: rotateX(80deg); } 34%,50% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); } 52% {-webkit-transform: rotateX(80deg);-moz-transform: rotateX(80deg);-ms-transform: rotateX(80deg);transform: rotateX(80deg); } 54%,100% {-webkit-transform: rotateX(0deg);-moz-transform: rotateX(0deg);-ms-transform: rotateX(0deg);transform: rotateX(0deg); } }
    [not-existing] {
        zoom: 1;
    }
    .moon {
        background: url("http://yagz.net/testrealm/404/moon.png");
        width: 94px;
        height: 94px;
        position: absolute;
        left: 564px;
        top: 25px;
        -webkit-animation: moon-float 6s infinite ease-in-out;
        -moz-animation: moon-float 6s infinite ease-in-out;
        -o-animation: moon-float 6s infinite ease-in-out;
        animation: moon-float 6s infinite ease-in-out;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes moon-float{ 0% { -webkit-transform: translate(0, 20px) scale(1.1); } 65% { -webkit-transform: translate(0, 0px) scale(1.0); } 100% { -webkit-transform: translate(0, 20px) scale(1.1); } }
    @-moz-keyframes moon-float{ 0% { -moz-transform: translate(0, 20px) scale(1.1); } 65% { -moz-transform: translate(0, 0px) scale(1.0); } 100% { -moz-transform: translate(0, 20px) scale(1.1); } }
    @-o-keyframes moon-float{ 0% { -o-transform: translate(0, 20px) scale(1.1); } 65% { -o-transform: translate(0, 0px) scale(1.0); } 100% { -o-transform: translate(0, 20px) scale(1.1); } }
    @keyframes moon-float{ 0% {-webkit-transform: translate(0, 20px) scale(1.1);-moz-transform: translate(0, 20px) scale(1.1);-ms-transform: translate(0, 20px) scale(1.1);transform: translate(0, 20px) scale(1.1); } 65% {-webkit-transform: translate(0, 0px) scale(1.0);-moz-transform: translate(0, 0px) scale(1.0);-ms-transform: translate(0, 0px) scale(1.0);transform: translate(0, 0px) scale(1.0); } 100% {-webkit-transform: translate(0, 20px) scale(1.1);-moz-transform: translate(0, 20px) scale(1.1);-ms-transform: translate(0, 20px) scale(1.1);transform: translate(0, 20px) scale(1.1); } }
    [not-existing] {
        zoom: 1;
    }
    .platform {
        background: url("http://yagz.net/testrealm/404/platform.png");
        width: 163px;
        height: 79px;
        position: absolute;
        left: 58px;
        top: 355px;
    }
    .star1 {
        background: url("http://yagz.net/testrealm/404/star1.png");
        width: 37px;
        height: 37px;
        position: absolute;
        left: 66px;
        top: 208px;
        -webkit-animation: star1 12s infinite linear, star1-fade 12s infinite ease-in-out;
        -moz-animation: star1 12s infinite linear, star1-fade 12s infinite ease-in-out;
        -o-animation: star1 12s infinite linear, star1-fade 12s infinite ease-in-out;
        animation: star1 12s infinite linear, star1-fade 12s infinite ease-in-out;
    }
    .star2 {
        background: url("http://yagz.net/testrealm/404/star2.png");
        width: 37px;
        height: 37px;
        position: absolute;
        left: 446px;
        top: 73px;
        -webkit-animation: star2 12s infinite linear, star2-fade 12s infinite ease-in-out;
        -moz-animation: star2 12s infinite linear, star2-fade 12s infinite ease-in-out;
        -o-animation: star2 12s infinite linear, star2-fade 12s infinite ease-in-out;
        animation: star2 12s infinite linear, star2-fade 12s infinite ease-in-out;
    }
    .star3 {
        background: url("http://yagz.net/testrealm/404/star3.png");
        width: 23px;
        height: 21px;
        position: relative;
        left: 680px;
        top: 281px;
        -webkit-animation: star3 12s infinite linear, star3-fade 12s infinite ease-in-out;
        -moz-animation: star3 12s infinite linear, star3-fade 12s infinite ease-in-out;
        -o-animation: star3 12s infinite linear, star3-fade 12s infinite ease-in-out;
        animation: star3 12s infinite linear, star3-fade 12s infinite ease-in-out;
    }
    .star4 {
        background: url("http://yagz.net/testrealm/404/star4.png");
        width: 23px;
        height: 21px;
        position: absolute;
        left: 232px;
        top: 336px;
        -webkit-animation: star4 12s infinite linear, star4-fade 12s infinite ease-in-out;
        -moz-animation: star4 12s infinite linear, star4-fade 12s infinite ease-in-out;
        -o-animation: star4 12s infinite linear, star4-fade 12s infinite ease-in-out;
        animation: star4 12s infinite linear, star4-fade 12s infinite ease-in-out;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes star1{ 0% { -webkit-transform: scale(.5)  skewX(15deg) rotateZ(0deg); } 15% { -webkit-transform: scale(1) skewX(0deg) rotateZ(360deg); } 30%,100% {  -webkit-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @-moz-keyframes star1{ 0% { -moz-transform: scale(.5)  skewX(15deg) rotateZ(0deg); } 15% { -moz-transform: scale(1) skewX(0deg) rotateZ(360deg); } 30%,100% {  -moz-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @-o-keyframes star1{ 0% { -o-transform: scale(.5)  skewX(15deg) rotateZ(0deg); } 15% { -o-transform: scale(1) skewX(0deg) rotateZ(360deg); } 30%,100% {  -o-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @keyframes star1{ 0% {-webkit-transform: scale(.5)  skewX(15deg) rotateZ(0deg);-moz-transform: scale(.5)  skewX(15deg) rotateZ(0deg);-ms-transform: scale(.5)  skewX(15deg) rotateZ(0deg);transform: scale(.5)  skewX(15deg) rotateZ(0deg); } 15% {-webkit-transform: scale(1) skewX(0deg) rotateZ(360deg);-moz-transform: scale(1) skewX(0deg) rotateZ(360deg);-ms-transform: scale(1) skewX(0deg) rotateZ(360deg);transform: scale(1) skewX(0deg) rotateZ(360deg); } 30%,100% {-webkit-transform: scale(.5) skewX(15deg) rotateZ(720deg);-moz-transform: scale(.5) skewX(15deg) rotateZ(720deg);-ms-transform: scale(.5) skewX(15deg) rotateZ(720deg);transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes star2{ 0%,15% { -webkit-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 30% { -webkit-transform: scale(1) skewX(0deg) rotateZ(360deg); } 45%,100% {  -webkit-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @-moz-keyframes star2{ 0%,15% { -moz-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 30% { -moz-transform: scale(1) skewX(0deg) rotateZ(360deg); } 45%,100% {  -moz-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @-o-keyframes star2{ 0%,15% { -o-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 30% { -o-transform: scale(1) skewX(0deg) rotateZ(360deg); } 45%,100% {  -o-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @keyframes star2{ 0%,15% {-webkit-transform: scale(.5) skewX(15deg) rotateZ(0deg);-moz-transform: scale(.5) skewX(15deg) rotateZ(0deg);-ms-transform: scale(.5) skewX(15deg) rotateZ(0deg);transform: scale(.5) skewX(15deg) rotateZ(0deg); } 30% {-webkit-transform: scale(1) skewX(0deg) rotateZ(360deg);-moz-transform: scale(1) skewX(0deg) rotateZ(360deg);-ms-transform: scale(1) skewX(0deg) rotateZ(360deg);transform: scale(1) skewX(0deg) rotateZ(360deg); } 45%,100% {-webkit-transform: scale(.5) skewX(15deg) rotateZ(720deg);-moz-transform: scale(.5) skewX(15deg) rotateZ(720deg);-ms-transform: scale(.5) skewX(15deg) rotateZ(720deg);transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes star3{ 0%,30% { -webkit-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 45% { -webkit-transform: scale(1) skewX(0deg) rotateZ(360deg); } 60%,100% {  -webkit-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @-moz-keyframes star3{ 0%,30% { -moz-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 45% { -moz-transform: scale(1) skewX(0deg) rotateZ(360deg); } 60%,100% {  -moz-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @-o-keyframes star3{ 0%,30% { -o-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 45% { -o-transform: scale(1) skewX(0deg) rotateZ(360deg); } 60%,100% {  -o-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @keyframes star3{ 0%,30% {-webkit-transform: scale(.5) skewX(15deg) rotateZ(0deg);-moz-transform: scale(.5) skewX(15deg) rotateZ(0deg);-ms-transform: scale(.5) skewX(15deg) rotateZ(0deg);transform: scale(.5) skewX(15deg) rotateZ(0deg); } 45% {-webkit-transform: scale(1) skewX(0deg) rotateZ(360deg);-moz-transform: scale(1) skewX(0deg) rotateZ(360deg);-ms-transform: scale(1) skewX(0deg) rotateZ(360deg);transform: scale(1) skewX(0deg) rotateZ(360deg); } 60%,100% {-webkit-transform: scale(.5) skewX(15deg) rotateZ(720deg);-moz-transform: scale(.5) skewX(15deg) rotateZ(720deg);-ms-transform: scale(.5) skewX(15deg) rotateZ(720deg);transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes star4{ 0%,45% { -webkit-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 60% { -webkit-transform: scale(1) skewX(0deg) rotateZ(360deg); } 75%,100% {  -webkit-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @-moz-keyframes star4{ 0%,45% { -moz-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 60% { -moz-transform: scale(1) skewX(0deg) rotateZ(360deg); } 75%,100% {  -moz-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @-o-keyframes star4{ 0%,45% { -o-transform: scale(.5) skewX(15deg) rotateZ(0deg); } 60% { -o-transform: scale(1) skewX(0deg) rotateZ(360deg); } 75%,100% {  -o-transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    @keyframes star4{ 0%,45% {-webkit-transform: scale(.5) skewX(15deg) rotateZ(0deg);-moz-transform: scale(.5) skewX(15deg) rotateZ(0deg);-ms-transform: scale(.5) skewX(15deg) rotateZ(0deg);transform: scale(.5) skewX(15deg) rotateZ(0deg); } 60% {-webkit-transform: scale(1) skewX(0deg) rotateZ(360deg);-moz-transform: scale(1) skewX(0deg) rotateZ(360deg);-ms-transform: scale(1) skewX(0deg) rotateZ(360deg);transform: scale(1) skewX(0deg) rotateZ(360deg); } 75%,100% {-webkit-transform: scale(.5) skewX(15deg) rotateZ(720deg);-moz-transform: scale(.5) skewX(15deg) rotateZ(720deg);-ms-transform: scale(.5) skewX(15deg) rotateZ(720deg);transform: scale(.5) skewX(15deg) rotateZ(720deg); } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes star1-fade{ 0% { opacity: 0;} 15% { opacity: 1; } 30%,100% { opacity: 0; } }
    @-moz-keyframes star1-fade{ 0% { opacity: 0;} 15% { opacity: 1; } 30%,100% { opacity: 0; } }
    @-o-keyframes star1-fade{ 0% { opacity: 0;} 15% { opacity: 1; } 30%,100% { opacity: 0; } }
    @keyframes star1-fade{ 0% { opacity: 0;} 15% { opacity: 1; } 30%,100% { opacity: 0; } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes star2-fade{ 0%,15% { opacity: 0;} 30% { opacity: 1; } 45%,100% { opacity: 0; } }
    @-moz-keyframes star2-fade{ 0%,15% { opacity: 0;} 30% { opacity: 1; } 45%,100% { opacity: 0; } }
    @-o-keyframes star2-fade{ 0%,15% { opacity: 0;} 30% { opacity: 1; } 45%,100% { opacity: 0; } }
    @keyframes star2-fade{ 0%,15% { opacity: 0;} 30% { opacity: 1; } 45%,100% { opacity: 0; } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes star3-fade{ 0%,30% { opacity: 0;} 45% { opacity: 1; } 60%,100% { opacity: 0; } }
    @-moz-keyframes star3-fade{ 0%,30% { opacity: 0;} 45% { opacity: 1; } 60%,100% { opacity: 0; } }
    @-o-keyframes star3-fade{ 0%,30% { opacity: 0;} 45% { opacity: 1; } 60%,100% { opacity: 0; } }
    @keyframes star3-fade{ 0%,30% { opacity: 0;} 45% { opacity: 1; } 60%,100% { opacity: 0; } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes star4-fade{ 0%,45% { opacity: 0;} 60% { opacity: 1; } 75%,100% { opacity: 0; } }
    @-moz-keyframes star4-fade{ 0%,45% { opacity: 0;} 60% { opacity: 1; } 75%,100% { opacity: 0; } }
    @-o-keyframes star4-fade{ 0%,45% { opacity: 0;} 60% { opacity: 1; } 75%,100% { opacity: 0; } }
    @keyframes star4-fade{ 0%,45% { opacity: 0;} 60% { opacity: 1; } 75%,100% { opacity: 0; } }
    [not-existing] {
        zoom: 1;
    }
    .swirl {
        background: url("http://yagz.net/testrealm/404/swirl.png");
        width: 72px;
        height: 72px;
        position: absolute;
        left: 734px;
        top: 336px;
        -webkit-animation: swirl-float 4s infinite ease-in-out;
        -moz-animation: swirl-float 4s infinite ease-in-out;
        -o-animation: swirl-float 4s infinite ease-in-out;
        animation: swirl-float 4s infinite ease-in-out;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes swirl-float{ 0% { opacity: .2; -webkit-transform: scale(0.5); } 65% { opacity: 1; -webkit-transform: scale(1.3); } 100% { opacity: .2; -webkit-transform: scale(0.5); } }
    @-moz-keyframes swirl-float{ 0% { opacity: .2; -moz-transform: scale(0.5); } 65% { opacity: 1; -moz-transform: scale(1.3); } 100% { opacity: .2; -moz-transform: scale(0.5); } }
    @-o-keyframes swirl-float{ 0% { opacity: .2; -o-transform: scale(0.5); } 65% { opacity: 1; -o-transform: scale(1.3); } 100% { opacity: .2; -o-transform: scale(0.5); } }
    @keyframes swirl-float{ 0% { opacity: .2;-webkit-transform: scale(0.5);-moz-transform: scale(0.5);-ms-transform: scale(0.5);transform: scale(0.5); } 65% { opacity: 1;-webkit-transform: scale(1.3);-moz-transform: scale(1.3);-ms-transform: scale(1.3);transform: scale(1.3); } 100% { opacity: .2;-webkit-transform: scale(0.5);-moz-transform: scale(0.5);-ms-transform: scale(0.5);transform: scale(0.5); } }
    [not-existing] {
        zoom: 1;
    }
    .sword {
        background: url("http://yagz.net/testrealm/404/sworda.png");
        width: 100px;
        height: 78px;
        position: absolute;
        left: 335px;
        top: 127px;
        transform-origin: 100px 78px;
        -webkit-animation: sword 3s infinite ease-out;
        -moz-animation: sword 3s infinite ease-out;
        -o-animation: sword 3s infinite ease-out;
        animation: sword 3s infinite ease-out;
    }
    .sword-shadow {
        background: url("http://yagz.net/testrealm/404/sword-shadow.png");
        width: 22px;
        height: 45px;
        position: absolute;
        left: 28px;
        top: 37px;
        transform-origin: 72px 41px;
        -webkit-animation: sword-shadow 3s infinite ease-out;
        -moz-animation: sword-shadow 3s infinite ease-out;
        -o-animation: sword-shadow 3s infinite ease-out;
        animation: sword-shadow 3s infinite ease-out;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes sword{ 0%,15% { -webkit-transform:rotate(-40deg); } 87% { -webkit-transform:rotate(50deg);  } 100% { -webkit-transform:rotate(-40deg); } }
    @-moz-keyframes sword{ 0%,15% { -moz-transform:rotate(-40deg); } 87% { -moz-transform:rotate(50deg);  } 100% { -moz-transform:rotate(-40deg); } }
    @-o-keyframes sword{ 0%,15% { -o-transform:rotate(-40deg); } 87% { -o-transform:rotate(50deg);  } 100% { -o-transform:rotate(-40deg); } }
    @keyframes sword{ 0%,15% {-webkit-transform:rotate(-40deg);-moz-transform:rotate(-40deg);-ms-transform:rotate(-40deg);transform:rotate(-40deg); } 87% {-webkit-transform:rotate(50deg);-moz-transform:rotate(50deg);-ms-transform:rotate(50deg);transform:rotate(50deg);  } 100% {-webkit-transform:rotate(-40deg);-moz-transform:rotate(-40deg);-ms-transform:rotate(-40deg);transform:rotate(-40deg); } }
    [not-existing] {
        zoom: 1;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes sword-shadow{ 0%,15% { opacity: 0; -webkit-transform: scale(1.1);  } 30% { opacity: 1; -webkit-transform: scale(1); } 100% { opacity: 0; -webkit-transform: scale(1.1); } }
    @-moz-keyframes sword-shadow{ 0%,15% { opacity: 0; -moz-transform: scale(1.1);  } 30% { opacity: 1; -moz-transform: scale(1); } 100% { opacity: 0; -moz-transform: scale(1.1); } }
    @-o-keyframes sword-shadow{ 0%,15% { opacity: 0; -o-transform: scale(1.1);  } 30% { opacity: 1; -o-transform: scale(1); } 100% { opacity: 0; -o-transform: scale(1.1); } }
    @keyframes sword-shadow{ 0%,15% { opacity: 0;-webkit-transform: scale(1.1);-moz-transform: scale(1.1);-ms-transform: scale(1.1);transform: scale(1.1);  } 30% { opacity: 1;-webkit-transform: scale(1);-moz-transform: scale(1);-ms-transform: scale(1);transform: scale(1); } 100% { opacity: 0;-webkit-transform: scale(1.1);-moz-transform: scale(1.1);-ms-transform: scale(1.1);transform: scale(1.1); } }
    [not-existing] {
        zoom: 1;
    }
    .tetris {
        background: url("http://yagz.net/testrealm/404/tetris.png");
        width: 96px;
        height: 96px;
        position: absolute;
        left: 459px;
        top: 312px;
        -webkit-animation: rotate 10s steps(1) infinite alternate;
        -moz-animation: rotate 10s steps(1) infinite alternate;
        -o-animation: rotate 10s steps(1) infinite alternate;
        animation: rotate 10s steps(1) infinite alternate;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes rotate{ 0% { -webkit-transform: rotateZ(0deg); } 25% { -webkit-transform: rotateZ(90deg); } 50% { -webkit-transform: rotateZ(180deg); } 75% { -webkit-transform: rotateZ(270deg); } 100% { -webkit-transform: rotateZ(360deg); }}
    @-moz-keyframes rotate{ 0% { -moz-transform: rotateZ(0deg); } 25% { -moz-transform: rotateZ(90deg); } 50% { -moz-transform: rotateZ(180deg); } 75% { -moz-transform: rotateZ(270deg); } 100% { -moz-transform: rotateZ(360deg); }}
    @-o-keyframes rotate{ 0% { -o-transform: rotateZ(0deg); } 25% { -o-transform: rotateZ(90deg); } 50% { -o-transform: rotateZ(180deg); } 75% { -o-transform: rotateZ(270deg); } 100% { -o-transform: rotateZ(360deg); }}
    @keyframes rotate{ 0% {-webkit-transform: rotateZ(0deg);-moz-transform: rotateZ(0deg);-ms-transform: rotateZ(0deg);transform: rotateZ(0deg); } 25% {-webkit-transform: rotateZ(90deg);-moz-transform: rotateZ(90deg);-ms-transform: rotateZ(90deg);transform: rotateZ(90deg); } 50% {-webkit-transform: rotateZ(180deg);-moz-transform: rotateZ(180deg);-ms-transform: rotateZ(180deg);transform: rotateZ(180deg); } 75% {-webkit-transform: rotateZ(270deg);-moz-transform: rotateZ(270deg);-ms-transform: rotateZ(270deg);transform: rotateZ(270deg); } 100% {-webkit-transform: rotateZ(360deg);-moz-transform: rotateZ(360deg);-ms-transform: rotateZ(360deg);transform: rotateZ(360deg); }}
    [not-existing] {
        zoom: 1;
    }
    .triforce {
        background: url("http://yagz.net/testrealm/404/triforce.png");
        width: 76px;
        height: 61px;
        position: absolute;
        left: 130px;
        top: 41px;
        -webkit-animation: triforce-float 3s infinite ease-in-out;
        -moz-animation: triforce-float 3s infinite ease-in-out;
        -o-animation: triforce-float 3s infinite ease-in-out;
        animation: triforce-float 3s infinite ease-in-out;
    }
    lesshat-selector {
        -lh-property: 0; }
    @-webkit-keyframes triforce-float{ 0% { -webkit-transform: translate(0, 0px) scale(0.90) rotateY(0deg); } 65% { -webkit-transform: translate(0, 30px) scale(1.0); } 100% { -webkit-transform: translate(0, -0px) scale(0.90) rotateY(0deg); } }
    @-moz-keyframes triforce-float{ 0% { -moz-transform: translate(0, 0px) scale(0.90) rotateY(0deg); } 65% { -moz-transform: translate(0, 30px) scale(1.0); } 100% { -moz-transform: translate(0, -0px) scale(0.90) rotateY(0deg); } }
    @-o-keyframes triforce-float{ 0% { -o-transform: translate(0, 0px) scale(0.90) rotateY(0deg); } 65% { -o-transform: translate(0, 30px) scale(1.0); } 100% { -o-transform: translate(0, -0px) scale(0.90) rotateY(0deg); } }
    @keyframes triforce-float{ 0% {-webkit-transform: translate(0, 0px) scale(0.90) rotateY(0deg);-moz-transform: translate(0, 0px) scale(0.90) rotateY(0deg);-ms-transform: translate(0, 0px) scale(0.90) rotateY(0deg);transform: translate(0, 0px) scale(0.90) rotateY(0deg); } 65% {-webkit-transform: translate(0, 30px) scale(1.0);-moz-transform: translate(0, 30px) scale(1.0);-ms-transform: translate(0, 30px) scale(1.0);transform: translate(0, 30px) scale(1.0); } 100% {-webkit-transform: translate(0, -0px) scale(0.90) rotateY(0deg);-moz-transform: translate(0, -0px) scale(0.90) rotateY(0deg);-ms-transform: translate(0, -0px) scale(0.90) rotateY(0deg);transform: translate(0, -0px) scale(0.90) rotateY(0deg); } }
    [not-existing] {
        zoom: 1;
    }


</style>



<div class="me404">
    

    <div class="the404"></div>
  <iframe style="margin-left:70px" width="700" height="700" src="https://lottiefiles.com/iframe/1380-bikingishard" frameborder="0" allowfullscreen></iframe>

</div>